//var name: String? = "Paulo"
//name = nil

//if name != nil{
// let nameTwo: String = name
//}

//1 - Default Value
//let nameResult: String = name ?? "Maria"
//print(nameResult)

//2 - If Let

//if let name{
//    print(name)
//}

// 3 - Guard let

//@MainActor func some(){
//    guard let name else{
//        print("Digite seu nome")
//        return
//    }
//    print(name)
//}
//some()

//Exercicio

let name: String? = "Paulo" //String
let number:Double? = 20.3   //Double
let numberTwo: String? = "20.5" //Float
let age: String? = "20" //Int
let gender: Int? = 0 //Bool

//Name transformando em String
if let name {
    let nameResult: String = name
}

//number transformando em double
@MainActor func some(){
    guard let number else{
        print("digite um double")
        return
    }
    print(number)
}
